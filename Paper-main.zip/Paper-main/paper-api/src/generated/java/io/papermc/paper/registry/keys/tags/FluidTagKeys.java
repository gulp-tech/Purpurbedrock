package io.papermc.paper.registry.keys.tags;

import static net.kyori.adventure.key.Key.key;

import io.papermc.paper.annotation.GeneratedClass;
import io.papermc.paper.registry.RegistryKey;
import io.papermc.paper.registry.tag.TagKey;
import net.kyori.adventure.key.Key;
import org.bukkit.Fluid;
import org.jspecify.annotations.NullMarked;

/**
 * Vanilla tag keys for {@link RegistryKey#FLUID}.
 *
 * @apiNote The fields provided here are a direct representation of
 * what is available from the vanilla game source. They may be
 * changed (including removals) on any Minecraft version
 * bump, so cross-version compatibility is not provided on the
 * same level as it is on most of the other API.
 */
@SuppressWarnings({
        "unused",
        "SpellCheckingInspection"
})
@NullMarked
@GeneratedClass
public final class FluidTagKeys {
    /**
     * {@code #minecraft:axolotl_tries_to_find}
     *
     * @apiNote This field is version-dependant and may be removed in future Minecraft versions
     */
    public static final TagKey<Fluid> AXOLOTL_TRIES_TO_FIND = create(key("axolotl_tries_to_find"));

    /**
     * {@code #minecraft:bubble_column_can_occupy}
     *
     * @apiNote This field is version-dependant and may be removed in future Minecraft versions
     */
    public static final TagKey<Fluid> BUBBLE_COLUMN_CAN_OCCUPY = create(key("bubble_column_can_occupy"));

    /**
     * {@code #minecraft:dolphin_tries_to_find}
     *
     * @apiNote This field is version-dependant and may be removed in future Minecraft versions
     */
    public static final TagKey<Fluid> DOLPHIN_TRIES_TO_FIND = create(key("dolphin_tries_to_find"));

    /**
     * {@code #minecraft:entity_floatable}
     *
     * @apiNote This field is version-dependant and may be removed in future Minecraft versions
     */
    public static final TagKey<Fluid> ENTITY_FLOATABLE = create(key("entity_floatable"));

    /**
     * {@code #minecraft:frog_tries_to_find_land_near}
     *
     * @apiNote This field is version-dependant and may be removed in future Minecraft versions
     */
    public static final TagKey<Fluid> FROG_TRIES_TO_FIND_LAND_NEAR = create(key("frog_tries_to_find_land_near"));

    /**
     * {@code #minecraft:lava}
     *
     * @apiNote This field is version-dependant and may be removed in future Minecraft versions
     */
    public static final TagKey<Fluid> LAVA = create(key("lava"));

    /**
     * {@code #minecraft:supports_frogspawn}
     *
     * @apiNote This field is version-dependant and may be removed in future Minecraft versions
     */
    public static final TagKey<Fluid> SUPPORTS_FROGSPAWN = create(key("supports_frogspawn"));

    /**
     * {@code #minecraft:supports_lily_pad}
     *
     * @apiNote This field is version-dependant and may be removed in future Minecraft versions
     */
    public static final TagKey<Fluid> SUPPORTS_LILY_PAD = create(key("supports_lily_pad"));

    /**
     * {@code #minecraft:supports_sugar_cane_adjacently}
     *
     * @apiNote This field is version-dependant and may be removed in future Minecraft versions
     */
    public static final TagKey<Fluid> SUPPORTS_SUGAR_CANE_ADJACENTLY = create(key("supports_sugar_cane_adjacently"));

    /**
     * {@code #minecraft:water}
     *
     * @apiNote This field is version-dependant and may be removed in future Minecraft versions
     */
    public static final TagKey<Fluid> WATER = create(key("water"));

    private FluidTagKeys() {
    }

    /**
     * Creates a tag key for {@link Fluid} in the registry {@code minecraft:fluid}.
     *
     * @param key the tag key's key
     * @return a new tag key
     */
    public static TagKey<Fluid> create(final Key key) {
        return TagKey.create(RegistryKey.FLUID, key);
    }
}
