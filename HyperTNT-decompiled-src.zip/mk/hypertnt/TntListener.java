// Decomcompiled with Vineflower (JS/WASM port @run-slicer/vf) from HyperTNT.jar
// Восстановлено из байткода: без комментариев, имена локальных переменных условны.
package mk.hypertnt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public final class TntListener implements Listener {
   private final HyperTNTPlugin plugin;
   private final Map<Location, String> placed = new HashMap();
   private final Map<UUID, List<ArmorStand>> holograms = new HashMap();
   private final Map<UUID, BukkitTask> tasks = new HashMap();
   private final Map<String, Long> cooldowns = new HashMap();

   public TntListener(HyperTNTPlugin plugin) {
      this.plugin = plugin;
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onPlace(BlockPlaceEvent event) {
      ItemStack item = event.getItemInHand();
      String id = this.plugin.getTntManager().getItemType(item);
      if (id != null) {
         TntManager.TntType type = this.plugin.getTntManager().getType(id);
         if (type != null) {
            Location location = event.getBlockPlaced().getLocation();
            this.placed.put(location, id);
            if (type.autoIgnite()) {
               Bukkit.getScheduler().runTask(this.plugin, () -> {
                  if (location.getBlock().getType() == Material.TNT) {
                     this.prime(location, type, event.getPlayer());
                  }
               });
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onBreak(BlockBreakEvent event) {
      Location location = event.getBlock().getLocation();
      String id = (String)this.placed.remove(location);
      if (id != null) {
         TntManager.TntType type = this.plugin.getTntManager().getType(id);
         if (type != null) {
            event.setDropItems(false);
            event.getBlock().getWorld().dropItemNaturally(location, this.plugin.getTntManager().createItem(id, 1));
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onInteract(PlayerInteractEvent event) {
      if (event.getHand() == EquipmentSlot.HAND) {
         Player player = event.getPlayer();
         ItemStack item = event.getItem();
         String id = this.plugin.getTntManager().getItemType(item);
         if (id != null) {
            TntManager.TntType type = this.plugin.getTntManager().getType(id);
            if (type != null && type.throwEnabled() && event.getAction().isRightClick()) {
               event.setCancelled(true);
               if (!this.checkCooldown(player, type)) {
                  return;
               }

               if (player.getGameMode() != GameMode.CREATIVE) {
                  item.setAmount(item.getAmount() - 1);
               }

               Location location = player.getEyeLocation();
               Vector direction = location.getDirection();
               double velocityXZ = type.config.getDouble("ignite.throw.velocity-xz", 0.9);
               double velocityY = type.config.getDouble("ignite.throw.velocity-y", 0.2);
               Vector velocity = new Vector(direction.getX() * velocityXZ, direction.getY() * velocityY, direction.getZ() * velocityXZ);
               TNTPrimed primed = this.spawnTnt(location.add(direction.multiply(0.6)), type);
               primed.setVelocity(velocity);
               this.startVisuals(primed, type);
               return;
            }
         }

         if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            Block block = event.getClickedBlock();
            if (block != null && block.getType() == Material.TNT) {
               if (item != null) {
                  if (item.getType() == Material.FLINT_AND_STEEL || item.getType() == Material.FIRE_CHARGE) {
                     String typeId = (String)this.placed.get(block.getLocation());
                     if (typeId != null) {
                        TntManager.TntType type = this.plugin.getTntManager().getType(typeId);
                        if (type != null) {
                           event.setCancelled(true);
                           if (this.checkCooldown(player, type)) {
                              this.prime(block.getLocation(), type, player);
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onRedstone(BlockRedstoneEvent event) {
      if (event.getNewCurrent() > 0) {
         Block block = event.getBlock();
         if (block.getType() == Material.TNT) {
            String id = (String)this.placed.get(block.getLocation());
            if (id != null) {
               TntManager.TntType type = this.plugin.getTntManager().getType(id);
               if (type != null) {
                  if (!type.config.getBoolean("ignite.allow.redstone", true)) {
                     event.setNewCurrent(0);
                  } else {
                     this.prime(block.getLocation(), type, null);
                     event.setNewCurrent(0);
                  }
               }
            }
         }
      }
   }

   private boolean checkCooldown(Player player, TntManager.TntType type) {
      int seconds = type.cooldown();
      if (seconds <= 0) {
         return true;
      } else {
         String key = player.getUniqueId() + ":" + type.id;
         long now = System.currentTimeMillis();
         long expires = (Long)this.cooldowns.getOrDefault(key, 0L);
         if (expires > now) {
            long remaining = (expires - now + 999L) / 1000L;
            player.sendMessage(ChatColor.RED + "Подождите " + remaining + " сек. перед использованием.");
            return false;
         } else {
            this.cooldowns.put(key, now + seconds * 1000L);
            return true;
         }
      }
   }

   private void prime(Location location, TntManager.TntType type, Player player) {
      if (location.getBlock().getType() == Material.TNT) {
         location.getBlock().setType(Material.AIR, false);
         this.placed.remove(location);
         TNTPrimed primed = this.spawnTnt(location.clone().add(0.5, 0.0, 0.5), type);
         this.startVisuals(primed, type);
      }
   }

   private TNTPrimed spawnTnt(Location location, TntManager.TntType type) {
      TNTPrimed primed = (TNTPrimed)location.getWorld().spawn(location, TNTPrimed.class);
      primed.setFuseTicks(Math.max(1, (int)Math.round(type.fuseSeconds() * 20.0)));
      primed.getPersistentDataContainer().set(this.plugin.getTntManager().getEntityKey(), PersistentDataType.STRING, type.id);
      return primed;
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onExplosionPrime(ExplosionPrimeEvent event) {
      if (event.getEntity() instanceof TNTPrimed primed) {
         String id = this.plugin.getTntManager().getEntityType(primed);
         if (id != null) {
            TntManager.TntType type = this.plugin.getTntManager().getType(id);
            if (type != null) {
               event.setCancelled(true);
               this.removeVisuals(primed.getUniqueId());
               this.plugin.getExplosionService().explode(primed.getLocation(), type, primed);
               primed.remove();
            }
         }
      }
   }

   private void startVisuals(TNTPrimed primed, TntManager.TntType type) {
      if (type.config.getBoolean("visual.hologram.enabled", false)) {
         List<String> lines = type.config.getStringList("visual.hologram.lines");
         List<ArmorStand> stands = new ArrayList();
         double height = type.config.getDouble("visual.hologram.height", 2.0);
         double spacing = type.config.getDouble("visual.hologram.line-spacing", 0.25);

         for (int i = 0; i < lines.size(); i++) {
            Location location = primed.getLocation().clone().add(0.0, height + i * spacing, 0.0);
            ArmorStand stand = (ArmorStand)location.getWorld().spawn(location, ArmorStand.class);
            stand.setInvisible(true);
            stand.setGravity(false);
            stand.setMarker(true);
            stand.setSmall(true);
            stand.setInvulnerable(true);
            stand.setCustomNameVisible(true);
            stands.add(stand);
         }

         this.holograms.put(primed.getUniqueId(), stands);
         BukkitTask task = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            if (primed.isDead()) {
               this.removeVisuals(primed.getUniqueId());
            } else {
               double seconds = primed.getFuseTicks() / 20.0;

               for (int i = 0; i < stands.size(); i++) {
                  ArmorStand standx = (ArmorStand)stands.get(i);
                  if (!standx.isDead()) {
                     String text = ((String)lines.get(i)).replace("{time}", String.format(Locale.US, "%.1f", new Object[]{seconds}));
                     standx.setCustomName(ChatColor.translateAlternateColorCodes('&', text));
                     standx.teleport(primed.getLocation().clone().add(0.0, height + i * spacing, 0.0));
                  }
               }
            }
         }, 0L, Math.max(1, type.config.getInt("visual.hologram.update-period-ticks", 4)));
         this.tasks.put(primed.getUniqueId(), task);
      }
   }

   private void removeVisuals(UUID id) {
      BukkitTask task = (BukkitTask)this.tasks.remove(id);
      if (task != null) {
         task.cancel();
      }

      List<ArmorStand> stands = (List<ArmorStand>)this.holograms.remove(id);
      if (stands != null) {
         for (ArmorStand stand : stands) {
            if (!stand.isDead()) {
               stand.remove();
            }
         }
      }
   }
}
