# CHANGELOG — что и когда добавлено

## 14.11.2026 — v1.0

Создан комплект `Purpurbedrock-Connection-Kit` для создателя ядра Purpurbedrock 26.2.

**Важно:** исходники ядра и рабочий сервер `VoidPE` не изменялись. Все файлы ниже — новые, лежат отдельно от сервера.

### Добавлено

| Файл / папка | Назначение |
|---|---|
| `00-ИНСТРУКЦИЯ.md` | Пошаговый старт: что открыть, что запустить, как применить профиль |
| `README.md` | Обзор комплекта, порты, структура, оговорки |
| `CONNECTION-MATRIX.md` | Матрица 24 кодеков: RakNet / NetherNet / LAN |
| `connection-matrix.csv` | 74 минорные версии `1.21.0–26.60` с протоколами |
| `connection-matrix.json` | 24 группы / 74 версии для автотестов |
| `connection-matrix.html` | Интерактивная таблица с фильтром |
| `connections/01-raknet-udp-19132.md` | Прямое подключение по IP |
| `connections/02-nethernet-webrtc.md` | NetherNet: signaling + WebRTC |
| `connections/03-lan-discovery.md` | Вкладка «Миры», лейауты v6/v7, loopback |
| `connections/04-hosting-and-nat.md` | Хостинг, Docker/Pterodactyl, CGNAT, IPv6 |
| `connections/05-auth-and-firewall.md` | Offline/Xbox auth, firewall, безопасность |
| `configs/bedrock.reference.yml` | Эталон `bedrock.yml` (config-schema 6) |
| `configs/profiles/bedrock.01-home-lan.yml` | Домашняя LAN-сеть |
| `configs/profiles/bedrock.02-public-raknet.yml` | Публичный сервер, прямой IP |
| `configs/profiles/bedrock.03-public-nethernet.yml` | Публичный сервер за NAT/CGNAT |
| `configs/profiles/bedrock.04-mobile-lte.yml` | Мобильный профиль (MTU/сжатие) |
| `configs/profiles/bedrock.05-strict-xbox.yml` | Только Xbox-вход |
| `scripts/check-ports.ps1` | Проверка портов, firewall, RakNet-пинг, TCP signaling |
| `scripts/collect-diagnostics.ps1` | Сбор диагностики в `.txt`/`.zip` |
| `scripts/unlock-windows-lan.bat` | Разблокировка LAN для UWP Minecraft |
| `players/01-kak-zaiti-1.21.x.md` | Инструкция игроку 1.21.x |
| `players/02-kak-zaiti-26.x.md` | Инструкция игроку 26.x |
| `players/03-esli-ne-zahodit.md` | Дерево диагностики для игрока |
| `creator/IMPLEMENTATION-NOTES.md` | Карта кода и версионные развилки |
| `creator/TEST-PLAN.md` | План тестов по версиям и транспортам |
| `creator/ISSUES-AND-IDEAS.md` | P0/P1/P2-улучшения ядра |
| `creator/REPORT-TEMPLATE.md` | Шаблон баг-репорта |

### Исправлено в процессе проверки

- `check-ports.ps1`: убрана конструкция `try` как выражения (несовместимо с Windows PowerShell 5.1); исправлено чтение `bedrock.yml`; дедупликация правил firewall; скрипты сохранены в UTF-8 с BOM.
- `collect-diagnostics.ps1`: корректное чтение UTF-8 (`bedrock.yml`, `purpur.yml`, `latest.log`); секция `bedrock:` читается как top-level (не `settings.bedrock`); добавлена запись `bedrock:` в отчёт.
- Удалены тестовые артефакты диагностики с данными рабочего сервера.

### Проверено

- `check-ports.ps1`: парсинг RakNet Unconnected Pong на mock-сервере (`protocol=2225`, `version=26.60`), негативные сценарии.
- `collect-diagnostics.ps1`: создание `.txt` и `.zip`, чтение конфигов и лога.
- JSON: 24 группы / 74 версии; CSV: 74 строки; YAML-профили: `config-schema: 6`, `transport: both`.

### Не входит

- Патчи исходников ядра (только рекомендации в `creator/ISSUES-AND-IDEAS.md`).
- Изменения рабочего `bedrock.yml`, `purpur.yml` или плагинов VoidPE.
- Автоматическое применение профилей — только вручную.
