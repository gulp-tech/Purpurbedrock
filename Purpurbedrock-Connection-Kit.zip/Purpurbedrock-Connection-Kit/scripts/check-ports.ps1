﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Purpurbedrock Connection Kit - проверка портов и RakNet-ответа.

.DESCRIPTION
    Проверяет:
      * локальные UDP/TCP-слушатели (19132/19133/19134/7551);
      * правила брандмауэра Purpurbedrock;
      * реальный RakNet Unconnected Ping (MOTD/протокол/версия);
      * TCP-сигналинг NetherNet;
      * ключевые значения bedrock.yml (если указан -ServerDir).

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\scripts\check-ports.ps1

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\scripts\check-ports.ps1 -HostName play.example.com -ServerDir C:\VoidPE
#>
[CmdletBinding()]
param(
    [string]$HostName = '127.0.0.1',
    [int]$Port = 19132,
    [int]$WebRtcPort = 19133,
    [int]$LanPort = 7551,
    [int]$IcePort = 19134,
    [int]$TimeoutMs = 3000,
    [string]$ServerDir = '',
    [switch]$SkipPing
)

$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$fail = 0

function Write-Head([string]$text) {
    Write-Host ''
    Write-Host ("=== " + $text + " ===") -ForegroundColor Cyan
}

function Write-Ok([string]$text) {
    Write-Host ("[OK] " + $text) -ForegroundColor Green
}

function Write-Warn([string]$text) {
    Write-Host ("[!!] " + $text) -ForegroundColor Yellow
    $script:fail = 1
}

function Write-Info([string]$text) {
    Write-Host ("     " + $text) -ForegroundColor Gray
}

function Test-TcpPort([string]$Target, [int]$TcpPort, [int]$Timeout) {
    try {
        $client = New-Object System.Net.Sockets.TcpClient
        $iar = $client.BeginConnect($Target, $TcpPort, $null, $null)
        $ok = $iar.AsyncWaitHandle.WaitOne($Timeout, $false)
        if ($ok) {
            $client.EndConnect($iar)
            $client.Close()
            return $true
        }
        $client.Close()
        return $false
    } catch {
        return $false
    }
}

function Invoke-RakNetPing([string]$Target, [int]$UdpPort, [int]$Timeout) {
    $magic = [byte[]](0x00,0xff,0xff,0x00,0xfe,0xfe,0xfe,0xfe,0xfd,0xfd,0xfd,0xfd,0x12,0x34,0x56,0x78)
    $ms = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    $time = [BitConverter]::GetBytes([int64]$ms)
    [Array]::Reverse($time)
    $guid = New-Object byte[] 8
    (New-Object System.Random).NextBytes($guid)

    $packet = New-Object System.Collections.Generic.List[byte]
    $packet.Add([byte]0x01)
    $packet.AddRange($time)
    $packet.AddRange($magic)
    $packet.AddRange($guid)
    $bytes = $packet.ToArray()

    $udp = New-Object System.Net.Sockets.UdpClient
    $udp.Client.ReceiveTimeout = $Timeout
    try {
        [void]$udp.Send($bytes, $bytes.Length, $Target, $UdpPort)
        $remote = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, 0)
        $response = $udp.Receive([ref]$remote)
        if ($response.Length -gt 35 -and $response[0] -eq 0x1C) {
            $motd = [System.Text.Encoding]::UTF8.GetString($response, 35, $response.Length - 35)
            $parts = $motd -split ';'
            return [pscustomobject]@{
                Motd     = if ($parts.Length -gt 1) { $parts[1] } else { '' }
                Protocol = if ($parts.Length -gt 2) { $parts[2] } else { '' }
                Version  = if ($parts.Length -gt 3) { $parts[3] } else { '' }
                Players  = if ($parts.Length -gt 4) { $parts[4] } else { '' }
                Max      = if ($parts.Length -gt 5) { $parts[5] } else { '' }
                Raw      = $motd
            }
        }
        return $null
    } catch {
        return $null
    } finally {
        $udp.Close()
    }
}

Write-Host 'Purpurbedrock Connection Kit - diagnostics' -ForegroundColor White
Write-Host ("Target: " + $HostName + "  |  " + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))

# ------------------------------------------------------------------
Write-Head 'Локальные UDP-слушатели'
$wantedUdp = @($Port, $WebRtcPort, $LanPort, $IcePort)
$udpEndpoints = @()
try {
    $udpEndpoints = Get-NetUDPEndpoint -ErrorAction Stop | Where-Object { $wantedUdp -contains $_.LocalPort }
} catch {
    Write-Info ('Get-NetUDPEndpoint недоступен: ' + $_.Exception.Message)
}

foreach ($p in $wantedUdp) {
    $listener = $udpEndpoints | Where-Object { $_.LocalPort -eq $p } | Select-Object -First 1
    if ($listener) {
        $proc = '?'
        try { $proc = (Get-Process -Id $listener.OwningProcess -ErrorAction Stop).ProcessName } catch {}
        Write-Ok ("UDP " + $p + " слушается (PID " + $listener.OwningProcess + ", " + $proc + ")")
    } else {
        if ($HostName -eq '127.0.0.1' -or $HostName -eq 'localhost') {
            Write-Warn ("UDP " + $p + " не слушается локально")
        } else {
            Write-Info ("UDP " + $p + " локально не найден (нормально для удалённой проверки)")
        }
    }
}

# ------------------------------------------------------------------
Write-Head 'Локальный TCP-сигналинг NetherNet'
$tcp = $null
try { $tcp = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue } catch {}
if ($tcp) {
    $first = $tcp | Select-Object -First 1
    Write-Ok ("TCP " + $Port + " слушается (PID " + $first.OwningProcess + ")")
} else {
    Write-Warn ("TCP " + $Port + " не слушается локально")
}

# ------------------------------------------------------------------
Write-Head 'Брандмауэр Windows'
try {
    $rules = Get-NetFirewallRule -DisplayName 'Purpurbedrock*' -ErrorAction Stop | Sort-Object DisplayName, Direction -Unique
    if ($rules) {
        foreach ($r in $rules) {
            Write-Ok ("Правило: " + $r.DisplayName + " (" + $r.Direction + ", " + $r.Action + ", " + $r.Enabled + ")")
        }
    } else {
        Write-Warn 'Правила Purpurbedrock* не найдены. Запустите unlock-windows-lan.bat от администратора.'
    }
} catch {
    Write-Info ('Правила брандмауэра не прочитаны: ' + $_.Exception.Message)
}

# ------------------------------------------------------------------
Write-Head 'bedrock.yml (если указан -ServerDir)'
if ($ServerDir -and (Test-Path (Join-Path $ServerDir 'bedrock.yml'))) {
    $cfg = Get-Content (Join-Path $ServerDir 'bedrock.yml') -Raw
    foreach ($key in @('address','port','transport','webrtc-port','public-address','lan-discovery','auth-type','xbox-auth-required','mtu','compression-level')) {
        $match = [regex]::Match($cfg, '(?m)^\s*' + [regex]::Escape($key) + '\s*:\s*(.+)$')
        if ($match.Success) {
            Write-Info ($key + ': ' + $match.Groups[1].Value.Trim())
        }
    }
} elseif ($ServerDir) {
    Write-Warn ('bedrock.yml не найден в ' + $ServerDir)
} else {
    Write-Info 'Параметр -ServerDir не указан; пропуск чтения конфига.'
}

# ------------------------------------------------------------------
Write-Head 'RakNet Unconnected Ping'
if ($SkipPing) {
    Write-Info 'Пропущено (-SkipPing).'
} else {
    $pong = Invoke-RakNetPing -Target $HostName -UdpPort $Port -Timeout $TimeoutMs
    if ($pong) {
        Write-Ok ("RakNet отвечает: MOTD='" + $pong.Motd + "' protocol=" + $pong.Protocol + " version=" + $pong.Version + " players=" + $pong.Players + "/" + $pong.Max)
        if ($pong.Protocol -and [int]$pong.Protocol -lt 685) {
            Write-Warn 'Протокол ниже v685 (1.21.0) - такой клиент не поддерживается этим ядром.'
        }
        if ($pong.Protocol -and [int]$pong.Protocol -gt 2225) {
            Write-Warn 'Протокол выше v2225 (26.60) - нужен новый кодек в ядре.'
        }
    } else {
        Write-Warn ("Нет ответа на RakNet ping " + $HostName + ":" + $Port + " (UDP). Проверьте порт/фаервол/NAT.")
    }
}

# ------------------------------------------------------------------
Write-Head 'NetherNet signaling (TCP)'
if (Test-TcpPort -Target $HostName -TcpPort $Port -Timeout $TimeoutMs) {
    Write-Ok ("TCP " + $Port + " доступен - signaling слушает")
} else {
    Write-Warn ("TCP " + $Port + " недоступен - NetherNet signaling не отвечает")
}

# ------------------------------------------------------------------
Write-Head 'Итог'
if ($fail -eq 0) {
    Write-Host 'Всё критичное в порядке.' -ForegroundColor Green
    exit 0
} else {
    Write-Host 'Есть замечания - смотрите [!!] выше.' -ForegroundColor Yellow
    exit 2
}
