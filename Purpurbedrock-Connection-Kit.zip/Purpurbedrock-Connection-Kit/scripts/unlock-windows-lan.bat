@echo off
chcp 65001 >nul
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Запрос прав Администратора для разблокировки локальной сети Minecraft Windows 10/11...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
echo [Purpurbedrock 26.2] Разблокировка локальной сети для всех установленных пакетов Minecraft...
CheckNetIsolation LoopbackExempt -a -n="Microsoft.MinecraftUWP_8wekyb3d8bbwe" >nul 2>&1
CheckNetIsolation LoopbackExempt -a -n="Microsoft.MinecraftWindowsBeta_8wekyb3d8bbwe" >nul 2>&1
for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "Get-AppxPackage '*Minecraft*' ^| ForEach-Object { $_.PackageFamilyName }"`) do CheckNetIsolation LoopbackExempt -a -n="%%P" >nul 2>&1
echo [Purpurbedrock 26.2] Обновление правил Брандмауэра Windows для LAN Discovery...
netsh advfirewall firewall delete rule name="Purpurbedrock LAN UDP" >nul 2>&1
netsh advfirewall firewall delete rule name="Purpurbedrock LAN TCP" >nul 2>&1
netsh advfirewall firewall add rule name="Purpurbedrock LAN UDP" dir=in action=allow protocol=UDP localport=7551,19132-19134 profile=any >nul 2>&1
netsh advfirewall firewall add rule name="Purpurbedrock LAN UDP" dir=out action=allow protocol=UDP localport=7551,19132-19134 profile=any >nul 2>&1
netsh advfirewall firewall add rule name="Purpurbedrock LAN TCP" dir=in action=allow protocol=TCP localport=19132 profile=any >nul 2>&1
netsh advfirewall firewall add rule name="Purpurbedrock LAN TCP" dir=out action=allow protocol=TCP localport=19132 profile=any >nul 2>&1
echo.
echo ГОТОВО. Полностью закройте Minecraft, запустите сервер, затем снова откройте Minecraft.
echo Сервер появится в разделе Миры только если сервер и компьютер находятся в одной локальной сети.
pause
