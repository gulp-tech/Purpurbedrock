﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Purpurbedrock Connection Kit - сбор диагностики в один файл (и опционально ZIP).

.DESCRIPTION
    Собирает:
      * версию ОС, PowerShell, Java;
      * список ключевых файлов сервера;
      * bedrock.yml и секцию bedrock из purpur.yml;
      * вывод check-ports.ps1 (порты, firewall, RakNet ping, TCP signaling);
      * последние строки logs/latest.log;
      * netstat по игровым портам.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\scripts\collect-diagnostics.ps1 -ServerDir C:\VoidPE -Zip

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\scripts\collect-diagnostics.ps1 -ServerDir C:\VoidPE -HostName play.example.com -Zip
#>
[CmdletBinding()]
param(
    [string]$ServerDir = '',
    [string]$HostName = '127.0.0.1',
    [string]$OutFile = '',
    [switch]$Zip
)

$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

if (-not $ServerDir) { $ServerDir = (Get-Location).Path }
$ServerDir = (Resolve-Path -LiteralPath $ServerDir -ErrorAction Stop).Path

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
if (-not $OutFile) {
    $OutFile = Join-Path (Split-Path -Parent $PSScriptRoot) ("Purpurbedrock-Diagnostics-" + $stamp + ".txt")
}

$lines = New-Object System.Collections.Generic.List[string]
function Add-Line([string]$text = '') { $lines.Add($text) }
function Add-Head([string]$text) {
    Add-Line ''
    Add-Line ('=== ' + $text + ' ===')
}

Add-Line ('Purpurbedrock diagnostics report')
Add-Line ('Generated: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'))
Add-Line ('ServerDir: ' + $ServerDir)
Add-Line ('Host: ' + $HostName)

# ------------------------------------------------------------------
Add-Head 'System'
Add-Line ('OS: ' + [System.Environment]::OSVersion.VersionString)
Add-Line ('Machine: ' + [System.Environment]::MachineName)
Add-Line ('PowerShell: ' + $PSVersionTable.PSVersion.ToString())
Add-Line ('64-bit process: ' + [System.Environment]::Is64BitProcess)
try {
    $java = & java -version 2>&1 | Out-String
    Add-Line ('Java: ' + $java.Trim())
} catch {
    Add-Line ('Java: not found (' + $_.Exception.Message + ')')
}

# ------------------------------------------------------------------
Add-Head 'Server files'
foreach ($name in @('purpurbedrock-26.2.jar','bedrock.yml','purpur.yml','server.properties','start.bat','unlock-windows-lan.bat','bedrock','plugins','logs')) {
    $path = Join-Path $ServerDir $name
    if (Test-Path -LiteralPath $path) {
        $item = Get-Item -LiteralPath $path
        if ($item.PSIsContainer) {
            $count = (Get-ChildItem -LiteralPath $path -Force -ErrorAction SilentlyContinue | Measure-Object).Count
            Add-Line ($name + ': dir, ' + $count + ' entries')
        } else {
            Add-Line ($name + ': file, ' + $item.Length + ' bytes, modified ' + $item.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss'))
        }
    } else {
        Add-Line ($name + ': MISSING')
    }
}

# ------------------------------------------------------------------
Add-Head 'bedrock.yml'
$bedrockPath = Join-Path $ServerDir 'bedrock.yml'
if (Test-Path -LiteralPath $bedrockPath) {
    Add-Line ([System.IO.File]::ReadAllText($bedrockPath, [System.Text.Encoding]::UTF8))
} else {
    Add-Line 'bedrock.yml not found'
}

# ------------------------------------------------------------------
Add-Head 'purpur.yml - bedrock'
$purpurPath = Join-Path $ServerDir 'purpur.yml'
if (Test-Path -LiteralPath $purpurPath) {
    $purpur = [System.IO.File]::ReadAllText($purpurPath, [System.Text.Encoding]::UTF8)
    $m = [regex]::Match($purpur, '(?ms)^bedrock:[ \t]*\r?\n(?<block>.*?)(?=^\S|\z)')
    if ($m.Success) {
        Add-Line 'bedrock:'
        Add-Line $m.Groups['block'].Value
    } else {
        Add-Line 'bedrock section not found'
    }
} else {
    Add-Line 'purpur.yml not found'
}

# ------------------------------------------------------------------
Add-Head 'check-ports.ps1'
$checkScript = Join-Path $PSScriptRoot 'check-ports.ps1'
if (Test-Path -LiteralPath $checkScript) {
    try {
        $checkOutput = & $checkScript -HostName $HostName -ServerDir $ServerDir 2>&1 | Out-String
        Add-Line $checkOutput.Trim()
    } catch {
        Add-Line ('check-ports.ps1 failed: ' + $_.Exception.Message)
    }
} else {
    Add-Line ('not found: ' + $checkScript)
}

# ------------------------------------------------------------------
Add-Head 'netstat (game ports)'
try {
    $ports = ':(19132|19133|19134|7551|25293)\s'
    $netstat = & netstat -ano 2>&1 | Select-String -Pattern $ports
    if ($netstat) {
        Add-Line ($netstat | Out-String).Trim()
    } else {
        Add-Line 'no matching sockets'
    }
} catch {
    Add-Line ('netstat failed: ' + $_.Exception.Message)
}

# ------------------------------------------------------------------
Add-Head 'latest.log (tail 200)'
$logPath = Join-Path $ServerDir 'logs\latest.log'
if (Test-Path -LiteralPath $logPath) {
    $logLines = [System.IO.File]::ReadAllLines($logPath, [System.Text.Encoding]::UTF8)
    Add-Line (($logLines | Select-Object -Last 200) -join [Environment]::NewLine)
} else {
    Add-Line 'logs/latest.log not found'
}

# ------------------------------------------------------------------
Set-Content -LiteralPath $OutFile -Value ($lines -join [Environment]::NewLine) -Encoding UTF8
Write-Host ('Report written: ' + $OutFile) -ForegroundColor Green

if ($Zip) {
    $zipPath = [System.IO.Path]::ChangeExtension($OutFile, '.zip')
    if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
    Compress-Archive -LiteralPath $OutFile -DestinationPath $zipPath
    Write-Host ('ZIP written: ' + $zipPath) -ForegroundColor Green
}
