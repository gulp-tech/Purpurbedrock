# Implementation notes для создателя ядра

Карта кода, версионные развилки и поведение конфигов. Всё привязано к исходникам `Purpurbedrock-arena-16aa0e1c-purpurbedrock.zip`.

---

## 1. Точка входа Bedrock-движка

`purpur-server/src/main/java/org/purpurmc/purpur/bedrock/BedrockBridgeBootstrap.java`

| Что делает | Где |
|---|---|
| Встроенный протокольный JAR | `EMBEDDED_RESOURCE = "/META-INF/bedrock/purpurbedrock-protocol.jar"` |
| Активные порты/транспорт/auth | поля `activeBedrockPort`, `activeWebrtcPort`, `activeLanDiscoveryPort`, `activeTransport`, `activeAuthMode` |
| Создание/миграция корневого `bedrock.yml` | `loadOrCreateBedrockConfig(...)` |
| Перенос `plugins/Geyser-Spigot/*` в `bedrock/` | `prepareBedrockDataDirectories(...)` |
| Генерация внутреннего конфига движка | `syncInternalEngineConfig(...)` → `cache/purpurbedrock/engine/config.yml` (schema 10) |
| Self-test 24 кодеков | `runProtocolSelfTest()` |
| Диагностика игрока | `startPlayerDiagnostics(UUID)` |

**Поток конфига:**

```
корневой bedrock.yml
   ↓ (syncInternalEngineConfig)
cache/purpurbedrock/engine/config.yml   ← генерируется при каждом старте, руками не править
   ↓
встроенный Geyser-совместимый движок
```

Ключи, которые ядро реально пробрасывает во внутренний конфиг: `address`, `port`, `transport`, `nethernet.webrtc-port`, `nethernet.public-address` (через `advertise-addresses`), `auth-type`, `xbox-auth-required` (→ `validate-bedrock-login`), `motd.*`, `max-players`, `gameplay.*`, `performance.mtu/compression-level/cache-images`, `packs.*`.

---

## 2. Регистрация 24 кодеков

`scripts/patch-bedrock-engine.py`, блок `GameProtocol.registerAllVersions` (строки ~1570–1594).

```java
register(Bedrock_v685.CODEC,  "1.21.0", "1.21.1");
register(Bedrock_v686.CODEC,  "1.21.2", "1.21.3");
register(Bedrock_v712.CODEC,  "1.21.20" ... "1.21.23");
register(Bedrock_v729.CODEC,  "1.21.30", "1.21.31");
register(Bedrock_v748.CODEC,  "1.21.40" ... "1.21.44");
register(Bedrock_v766.CODEC,  "1.21.50", "1.21.51");
register(Bedrock_v776.CODEC,  "1.21.60" ... "1.21.62");
register(Bedrock_v786.CODEC,  "1.21.70" ... "1.21.73");
register(Bedrock_v800.CODEC,  "1.21.80" ... "1.21.84");
register(Bedrock_v818.CODEC,  "1.21.90" ... "1.21.92");
register(Bedrock_v819.CODEC,  "1.21.93", "1.21.94");
register(Bedrock_v827.CODEC,  "1.21.100", "1.21.101");
register(Bedrock_v844.CODEC,  "1.21.110" ... "1.21.114");
register(Bedrock_v859.CODEC,  "1.21.120" ... "1.21.123");
register(Bedrock_v860.CODEC,  "1.21.124");
register(Bedrock_v898.CODEC,  "1.21.130" ... "1.21.132");
register(Bedrock_v924.CODEC,  "26.0" ... "26.3");
register(Bedrock_v944.CODEC,  "26.10" ... "26.12");
register(Bedrock_v975.CODEC,  "26.20" ... "26.23");
register(Bedrock_v1001.CODEC, "26.30" ... "26.34");
register(Bedrock_v2168_hotfix4.CODEC, "26.40" ... "26.44");
register(Bedrock_v2169.CODEC, "26.45");
register(Bedrock_v2193.CODEC, "26.50" ... "26.52");
register(Bedrock_v2225.CODEC, "26.60");
```

Self-test ожидает ровно этот список:

```java
int[] expectedProtocols = {
    685, 686, 712, 729, 748, 766, 776, 786, 800, 818, 819,
    827, 844, 859, 860, 898, 924, 944, 975, 1001, 2168, 2169, 2193, 2225
};
```

При добавлении новой версии обновите **оба** места и добавьте палитры/маппинги.

---

## 3. Версионные развилки (не потерять при обновлении)

| Версия | Что сделано | Где |
|---|---|---|
| `< v818` (1.21.80 и ниже) | Фикс `StartGameSerializer_v428.writeSyncedPlayerMovementSettings` — защита от NPE на `null ordinal` | `scripts/patch-bedrock-engine.py`, ~2522 |
| `< v1001` (до 26.30) | Серный куб → слизень; звуки `ABSORB_BLOCK`/`EJECT_BLOCK` → звук слизня; метаданные таймера не отправляются | `scripts/patch-bedrock-engine.py` (~149, 1726, 1773, 1802, 6838) |
| `1.21.90 – 1.21.124` | Палитры, `item_components`, теги | `scripts/patch-bedrock-engine.py` (~57) |
| `26.30+` | Нативные `minecraft:sulfur_cube`, `absorb_block`, `eject_block` | тот же файл |
| `26.40 – 26.45` | LAN-лейаут **v6** | `scripts/bedrock-lan/ServerData.java` |
| `26.50 – 26.60` | LAN-лейаут **v7** | `scripts/bedrock-lan/ServerData.java` |
| `26.60` | `playerCount = max(1, ...)`, иначе клиент скрывает пустой LAN-мир | `scripts/bedrock-lan/NetherNetDiscovery.java`, ~120 |
| `26.40+` | `TransportDisconnectReason` / `ABORTED_BY_REMOTE_PEER` (обратная совместимость транспорта) | `scripts/bedrock-lan/TransportDisconnectReason.java` |
| Все | `pre-818`, `attrSingleton`, `waypointFix`, `configDialogSafe`, `chunkBoundsSafe`, `lanStatusV7`, `transportReason` в self-test | `BedrockBridgeBootstrap.runProtocolSelfTest` |

---

## 4. Транспорты

### RakNet

- UDP `port` (19132).
- Отвечает на Unconnected Ping строкой `MCPE;...`.
- Работает для всех 24 кодеков.
- Настройки лимитов — `purpur.yml → bedrock.network.*` (`raknet-packet-limit`, `global-packet-limit`, `max-connections-per-ip`, `send-cookie`).

### NetherNet

- TCP `port` — HTTP/WebSocket signaling (`mode: builtin`).
- UDP `nethernet.webrtc-port` — WebRTC.
- `nethernet.public-address` → `signaling.builtin.advertise-addresses`.
- Автоопределение публичного IPv4 — `resolveAdvertiseAddressesYaml(...)`.
- `transport` прокидывается в внутренний `bedrock.transport` как есть.

### LAN Discovery

- UDP `lan-discovery.port` (7551) — `NetherNetDiscoverySignaling`.
- UDP `lan-discovery.ice-port` (19134).
- Классы: `NetherNetDiscovery.java`, `ServerData.java`.
- Discovery-запрос не содержит версию клиента → сервер отправляет **оба** лейаута (v6 и v7) подряд.
- `PURPURBEDROCK_LAN_V7` и `PURPURBEDROCK_LAN_STATUS_V6_V7` проверяются self-test’ом.
- 26.60 скрывает мир с 0 игроков → `max(1, playerCount)`.

---

## 5. Auth

`syncInternalEngineConfig`:

```text
auth-type = auto:
  floodgate ready? -> floodgate
  иначе server.usesAuthentication()? -> online
  иначе -> offline

auth-type = floodgate, но Floodgate нет -> offline
иначе -> configured value
```

`xbox-auth-required` → `advanced.bedrock.validate-bedrock-login`.

**Замечание:** откат `floodgate → offline` сейчас молчаливый; стоит добавить WARN.

---

## 6. Java-гейткипер

`BedrockGatekeeper.java`:

- `only-allow-bedrock: true` → прямой Java-вход отклоняется.
- Bedrock-сессия определяется по `LocalChannel`, имени класса (`geyser`, `floodgate`), pipeline-хендлерам, `hostname`, `allowed-bridge-ips`.
- Текст отказа — `bedrock.reject-java-message` в `purpur.yml`.

Важно: это защита от Java-клиентов, **не** аутентификация Bedrock-игроков.

---

## 7. Команды и лимиты

- `/purpurbedrock` (`/pb`) — `PurpurBedrockCommand.java`.
  - `/pb status` — сводка, TPS, порты, папки, протокол.
  - `/pb menu`, `/pb chunks`, `/pb papi`, `/pb antixray`.
- `BedrockCommandLimits.java`:
  ```java
  if (upgradeLegacyDefault && configured == 96) configured = 512;
  return clamp(configured, 32, 1024);
  ```
  Это объясняет лог `advertised command limit: 512 (configured 96)` — не баг.
- `max-client-commands` в `bedrock.yml` и `purpur.yml` должен совпадать по смыслу; сейчас в VoidPE `96` и `96`, рекламируется `512`.

---

## 8. Производительность/совместимость (Bedrock-специфика)

| Класс | Назначение |
|---|---|
| `BedrockMovementGuard` | убирает ложные `moved wrongly` / `moved too quickly` |
| `BedrockGhostBlockResync` | ресинк блока и 6 граней при отмене/застревании |
| `BedrockChunkDowngrader` | совместимость чанков 26.3 → 26.2 |
| `BedrockChunkHelper` | `ensureChunkPublished`, `forceUpdateChunkPositionBlock` |
| `BedrockAntiXrayHelper` | Anti-Xray `EngineMode.HIDE` |
| `BedrockNpcOptimizer` | профили SAFE/BALANCED/HIGH |
| `BedrockCombatHelper` | Bedrock-боёвка 1.8 |
| `BedrockPlaceholderHook` | `%purpurbedrock_*%` |
| `JavaChestMenuManager` | Java-меню (DeluxeMenus) для Bedrock |

---

## 9. Self-test и CI

- `runProtocolSelfTest()` проверяет:
  - 24 кодека;
  - BlockMappings, ItemMappings (>1000 предметов), ItemTags, PotionMixes для каждого протокола;
  - LAN v6/v7 маркеры;
  - `TransportDisconnectReason.ABORTED_BY_REMOTE_PEER`;
  - санитизацию ников и офлайн-XUID;
  - русские локали;
  - chunk publisher.
- `.github/workflows/build.yml`:
  - grep по `register(Bedrock_v2225.CODEC, "26.60")` (строка ~110);
  - grep по LAN-маркерам (~112–114);
  - smoke-тест: RakNet Pong на UDP `19132`, TCP-сигналинг на `19132`, два синтетических клиента;
  - обязательные строки лога (~494–526).

При изменении транспортов/версий обновляйте эти проверки вместе с кодом.

---

## 10. Известные пробелы (детали — в `ISSUES-AND-IDEAS.md`)

1. `address: 0.0.0.0` — IPv4-only; IPv6-listener отсутствует.
2. LAN-лейаут для `26.30–26.34` не подтверждён.
3. `transport` кроме `both` не покрыт self-test.
4. Нет кастомного сообщения для неподдерживаемой версии клиента.
5. `lan-discovery.ice-port` не проверяется на коллизию с `port`/`webrtc-port`.
6. Нет счётчика/диагностики discovery-запросов в `/pb status`.
